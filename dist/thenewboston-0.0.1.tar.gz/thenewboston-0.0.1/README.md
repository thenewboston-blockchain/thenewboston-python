## Overview

Python library for thenewboston.

## Testing

To run tests:
```
python3 -m unittest
```

## Building

To produce a source distribution:
```
python3 setup.py sdist
```
