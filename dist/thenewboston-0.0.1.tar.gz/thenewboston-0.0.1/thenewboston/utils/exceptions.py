class NetworkException(Exception):
    pass
